# Vault

Fault-tolerant distributed object-storage simulator for a hackathon.

## What it demonstrates

Vault stores each uploaded object on three simulated storage nodes, records metadata in SQLite, verifies replicas with SHA-256, survives a node failure, detects corrupted data, and repairs bad/missing replicas from a verified source.

## Run the backend

From the repository root:

```powershell
& "C:\PulseCutAI\vault\.venv\Scripts\Activate.ps1"
python -m pip install -r requirements.txt
python -m uvicorn vault.api:app --reload --port 8000
```

## Run the frontend

In a second terminal:

```powershell
cd frontend
npm install
npm run dev
```

Open the URL printed by Vite.

## Test

```powershell
pytest -q
cd frontend
npm run build
```

## Demonstration workflow

1. Upload a file.
2. Confirm three replicas appear.
3. Download or verify the object.
4. Fail one node and verify retrieval still works.
5. Corrupt a replica, run Verify, and observe the checksum mismatch.
6. Repair the corrupted/missing replica and verify it again.
7. Recover the failed node.

## Design notes

- Storage nodes are simulated as independent filesystem directories on one machine.
- SQLite stores object, replica, node, event, and repair metadata.
- SHA-256 is calculated in chunks to support large files without loading the entire file into memory.
- The dashboard refreshes after user actions instead of continuously polling four endpoints every 1.5 seconds.
- The UI includes keyboard-focus states, accessible labels, live status/error announcements, reduced-motion support, and text-based status indicators that do not depend only on color.

## Security controls

Object and node IDs are validated before filesystem access; resolved paths are checked to remain under the configured storage root; upload size is capped; filenames are sanitized to their final path component; uploaded data is treated only as bytes and is never executed.

## Scope

This is an educational local simulation, not a production distributed-storage service. It intentionally avoids cloud services, Docker, Kubernetes, Redis, and Kafka so the fault-tolerance behavior can be demonstrated on a single developer machine.
