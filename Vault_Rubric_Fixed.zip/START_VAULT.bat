@echo off
setlocal
cd /d "%~dp0"
title Vault Launcher
if not exist ".venv\Scripts\python.exe" (
  echo Creating Vault Python environment...
  py -3.12 -m venv .venv 2>nul || python -m venv .venv
)
call ".venv\Scripts\activate.bat"
echo Installing/checking backend dependencies...
python -m pip install -r requirements.txt
if not exist "frontend\node_modules" (
  echo Installing frontend dependencies...
  cd frontend
  call npm install
  cd ..
)
echo Starting backend...
start "Vault Backend" cmd /k "cd /d "%~dp0" && call .venv\Scripts\activate.bat && python -m uvicorn vault.api:app --reload --port 8000"
echo Starting frontend...
start "Vault Frontend" cmd /k "cd /d "%~dp0frontend" && npm run dev"
timeout /t 5 /nobreak >nul
start "" "http://localhost:5173"
echo.
echo Vault is starting at http://localhost:5173
pause
