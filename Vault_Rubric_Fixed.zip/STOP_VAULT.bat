@echo off
taskkill /FI "WINDOWTITLE eq Vault Backend*" /T /F >nul 2>&1
taskkill /FI "WINDOWTITLE eq Vault Frontend*" /T /F >nul 2>&1
echo Vault stopped.
pause
