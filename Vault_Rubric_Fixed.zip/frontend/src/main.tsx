import { ChangeEvent, useCallback, useEffect, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  Activity,
  AlertTriangle,
  CheckCircle,
  Cloud,
  Download,
  RefreshCw,
  ShieldCheck,
  Trash2,
  Upload,
  Wrench,
  X,
  Zap,
} from "lucide-react";
import "./style.css";

const API = import.meta.env.VITE_API_URL ?? "/api";

type NodeState = "HEALTHY" | "FAILED" | "DEGRADED" | "RECOVERING" | string;

interface NodeInfo {
  node_id: string;
  state: NodeState;
  path: string;
}

interface Replica {
  object_id: string;
  node_id: string;
  state: NodeState;
  sha256?: string;
  size?: number;
}

interface VaultObject {
  object_id: string;
  filename: string;
  size: number;
  sha256: string;
  created_at: string;
  replication_factor: number;
  replicas: Replica[];
}

interface Metrics {
  object_count: number;
  logical_bytes: number;
  physical_bytes: number;
  replication_factor: number;
  total_nodes: number;
  healthy_nodes: number;
  failed_nodes: number;
  degraded_nodes: number;
  recovering_nodes: number;
  replica_count: number;
  healthy_replica_count: number;
  missing_replicas: number;
  corrupted_replicas: number;
  bytes_recovered: number;
  repairs_completed: number;
  repair_duration_ms: number;
  storage_overhead: number;
}

interface EventItem {
  id: number;
  timestamp: string;
  event_type: string;
  object_id?: string | null;
  node_id?: string | null;
  message: string;
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const response = await fetch(`${API}${path}`, options);
  if (!response.ok) {
    let detail = "";
    try {
      const body = (await response.json()) as { detail?: string };
      detail = body.detail ? `: ${body.detail}` : "";
    } catch {
      // Non-JSON error responses are reported using the HTTP status.
    }
    throw new Error(`${options.method ?? "GET"} ${path} failed (${response.status})${detail}`);
  }
  return response.status === 204 ? (null as T) : ((await response.json()) as T);
}

const jsonOptions = (method: string): RequestInit => ({
  method,
  headers: { "Content-Type": "application/json" },
});

function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  let value = bytes;
  let unit = 0;
  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024;
    unit += 1;
  }
  return `${value.toFixed(value >= 10 || unit === 0 ? 0 : 1)} ${units[unit]}`;
}

function App() {
  const [nodes, setNodes] = useState<NodeInfo[]>([]);
  const [objects, setObjects] = useState<VaultObject[]>([]);
  const [metrics, setMetrics] = useState<Metrics>({} as Metrics);
  const [events, setEvents] = useState<EventItem[]>([]);
  const [busy, setBusy] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const refresh = useCallback(async () => {
    setRefreshing(true);
    try {
      // One batched refresh after user actions, rather than continuous polling.
      const [nextNodes, nextObjects, nextMetrics, nextEvents] = await Promise.all([
        request<NodeInfo[]>("/nodes"),
        request<VaultObject[]>("/objects"),
        request<Metrics>("/metrics"),
        request<EventItem[]>("/events"),
      ]);
      setNodes(nextNodes);
      setObjects(nextObjects);
      setMetrics(nextMetrics);
      setEvents(nextEvents);
      setLastUpdated(new Date());
      setError(null);
    } catch (cause) {
      const message = cause instanceof Error ? cause.message : "Unable to refresh Vault.";
      console.error(message);
      setError(message);
    } finally {
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const runAction = useCallback(
    async (path: string, options: RequestInit, successMessage?: string) => {
      setBusy(true);
      setError(null);
      setNotice(null);
      try {
        await request(path, options);
        if (successMessage) setNotice(successMessage);
        await refresh();
      } catch (cause) {
        const message = cause instanceof Error ? cause.message : "Action failed.";
        console.error(message);
        setError(message);
      } finally {
        setBusy(false);
      }
    },
    [refresh],
  );

  const uploadFile = async (file: File) => {
    setUploading(true);
    setError(null);
    setNotice(null);
    try {
      const form = new FormData();
      form.append("file", file);
      await request<VaultObject>("/objects", { method: "POST", body: form });
      setNotice(`${file.name} uploaded and replicated successfully.`);
      await refresh();
    } catch (cause) {
      const message = cause instanceof Error ? cause.message : "Upload failed.";
      console.error(message);
      setError(message);
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  const onFileChange = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) void uploadFile(file);
  };

  const deleteObject = async (object: VaultObject) => {
    const confirmed = window.confirm(
      `Delete "${object.filename}"? This permanently removes the object and all replicas.`,
    );
    if (!confirmed) return;
    await runAction(
      `/objects/${encodeURIComponent(object.object_id)}`,
      { method: "DELETE" },
      `${object.filename} deleted.`,
    );
  };

  const runDemo = async () => {
    await runAction(
      "/demo/run",
      { method: "POST" },
      "Fault-tolerance demo completed.",
    );
  };

  const corruptReplica = async (objectId: string, nodeId: string) => {
    await runAction(
      `/replicas/${encodeURIComponent(objectId)}/corrupt`,
      {
        ...jsonOptions("POST"),
        body: JSON.stringify({ node_id: nodeId }),
      },
      `${nodeId} replica intentionally corrupted; verify it to detect the mismatch.`,
    );
  };

  const repairObject = async (objectId: string, nodeId?: string) => {
    await runAction(
      `/objects/${encodeURIComponent(objectId)}/repair`,
      {
        ...jsonOptions("POST"),
        body: JSON.stringify(nodeId ? { node_id: nodeId } : {}),
      },
      "Repair operation completed.",
    );
  };

  const metricCards = [
    ["Healthy nodes", metrics.healthy_nodes ?? 0, CheckCircle],
    ["Failed nodes", metrics.failed_nodes ?? 0, AlertTriangle],
    ["Replicas", metrics.replica_count ?? 0, Cloud],
    ["Storage overhead", `${(metrics.storage_overhead ?? 0).toFixed(2)}x`, Activity],
  ] as const;

  return (
    <div className="app-shell">
      <header className="top" role="banner">
        <div className="bar">
          <div className="brand" aria-label="Vault fault-tolerant object storage">
            <Cloud aria-hidden="true" />
            <div>
              <b>VAULT</b>
              <small>Fault-tolerant object storage</small>
            </div>
          </div>

          <div className="topactions">
            <input
              ref={fileInputRef}
              id="vault-file-upload"
              className="file-input"
              type="file"
              disabled={busy || uploading}
              onChange={onFileChange}
              aria-describedby="upload-help"
            />
            <label htmlFor="vault-file-upload" className="uploadbtn" aria-disabled={busy || uploading}>
              <Upload size={16} aria-hidden="true" />
              {uploading ? "Uploading…" : "Upload file"}
            </label>
            <span id="upload-help" className="sr-only">
              Select one file to upload. Vault creates three replicas.
            </span>

            <button
              className="secondary"
              type="button"
              disabled={busy || refreshing}
              onClick={() => void refresh()}
              aria-label={refreshing ? "Refreshing Vault data" : "Refresh Vault data"}
            >
              <RefreshCw size={16} className={refreshing ? "spin" : ""} aria-hidden="true" />
              {refreshing ? "Refreshing…" : "Refresh"}
            </button>

            <button type="button" disabled={busy || uploading} onClick={() => void runDemo()}>
              <Zap size={16} aria-hidden="true" />
              {busy ? "Working…" : "Run fault-tolerance demo"}
            </button>
          </div>
        </div>
      </header>

      <main id="main-content" className="main" role="main">
        <div className="sr-only" aria-live="polite">
          {notice ?? error ?? ""}
        </div>

        {notice && (
          <div className="panel notice" role="status">
            <CheckCircle size={16} aria-hidden="true" />
            <span>{notice}</span>
            <button type="button" className="icon" onClick={() => setNotice(null)} aria-label="Dismiss success message">
              <X size={16} aria-hidden="true" />
            </button>
          </div>
        )}

        {error && (
          <div className="panel errorbanner" role="alert">
            <AlertTriangle size={16} aria-hidden="true" />
            <span>{error}</span>
            <button type="button" className="icon" onClick={() => setError(null)} aria-label="Dismiss error message">
              <X size={16} aria-hidden="true" />
            </button>
          </div>
        )}

        <section aria-labelledby="overview-heading">
          <h1 id="overview-heading" className="sr-only">Vault cluster overview</h1>
          <div className="cards">
            {metricCards.map(([label, value, Icon]) => (
              <article className="panel card" key={label}>
                <span>{label}</span>
                <Icon aria-hidden="true" />
                <strong>{value}</strong>
              </article>
            ))}
          </div>
        </section>

        <section aria-labelledby="nodes-heading">
          <h2 id="nodes-heading">Storage nodes</h2>
          <div className="grid">
            {nodes.map((node) => (
              <article className="panel node" key={node.node_id}>
                <div className="node-title">
                  <b>{node.node_id}</b>
                  <span className={`status ${node.state}`} aria-label={`Node state: ${node.state}`}>
                    {node.state}
                  </span>
                </div>
                <small>Simulated local storage node</small>
                {node.state === "FAILED" ? (
                  <button type="button" disabled={busy} onClick={() => void runAction(`/nodes/${node.node_id}/recover`, { method: "POST" }, `${node.node_id} recovery started.`)}>
                    Recover
                  </button>
                ) : (
                  <button type="button" className="danger" disabled={busy || node.state !== "HEALTHY"} onClick={() => void runAction(`/nodes/${node.node_id}/fail`, { method: "POST" }, `${node.node_id} failed.`)}>
                    Fail node
                  </button>
                )}
              </article>
            ))}
          </div>
        </section>

        <section className="panel" aria-labelledby="objects-heading">
          <div className="panelhead">
            <div>
              <h2 id="objects-heading">Objects</h2>
              <small>{objects.length} stored object{objects.length === 1 ? "" : "s"}</small>
            </div>
            <button className="refreshInline" type="button" disabled={refreshing} onClick={() => void refresh()}>
              <RefreshCw size={15} className={refreshing ? "spin" : ""} aria-hidden="true" />
              Refresh
            </button>
          </div>

          {objects.length === 0 ? (
            <div className="empty">
              <b>No files stored yet.</b>
              <span>Use <strong>Upload file</strong> above to create replicated storage.</span>
            </div>
          ) : (
            objects.map((object) => (
              <article className="object" key={object.object_id}>
                <div className="object-info">
                  <b>{object.filename}</b>
                  <span>{formatBytes(object.size)} · {object.replication_factor} replicas</span>
                  <code>{object.object_id}</code>
                  <code>SHA-256 {object.sha256}</code>
                </div>

                <div className="actions" aria-label={`Actions for ${object.filename}`}>
                  <a
                    href={`${API}/objects/${encodeURIComponent(object.object_id)}/download`}
                    aria-label={`Download ${object.filename}`}
                  >
                    <Download size={15} aria-hidden="true" /> Download
                  </a>
                  <button type="button" onClick={() => void runAction(`/objects/${encodeURIComponent(object.object_id)}/verify`, { method: "POST" }, "Integrity verification completed.")}>
                    <ShieldCheck size={15} aria-hidden="true" /> Verify
                  </button>
                  <button type="button" onClick={() => void repairObject(object.object_id)} disabled={busy}>
                    <Wrench size={15} aria-hidden="true" /> Repair
                  </button>
                  <button type="button" className="danger" onClick={() => void deleteObject(object)} disabled={busy}>
                    <Trash2 size={15} aria-hidden="true" /> Delete
                  </button>
                </div>

                <div className="replicas" aria-label={`Replicas for ${object.filename}`}>
                  {object.replicas.map((replica) => (
                    <div className="replica-row" key={replica.node_id}>
                      <span className={`rep ${replica.state}`}>{replica.node_id} · {replica.state}</span>
                      <button
                        type="button"
                        className="micro"
                        disabled={busy || replica.state === "UNAVAILABLE"}
                        onClick={() => void corruptReplica(object.object_id, replica.node_id)}
                        aria-label={`Corrupt ${replica.node_id} replica of ${object.filename}`}
                      >
                        Corrupt
                      </button>
                      {(replica.state === "CORRUPTED" || replica.state === "MISSING") && (
                        <button type="button" className="micro" disabled={busy} onClick={() => void repairObject(object.object_id, replica.node_id)}>
                          Repair
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </article>
            ))
          )}
        </section>

        <div className="lower">
          <section className="panel" aria-labelledby="recovery-heading">
            <div className="panelhead"><h2 id="recovery-heading">Recovery metrics</h2></div>
            <div className="metricgrid">
              {[
                ["Bytes recovered", formatBytes(metrics.bytes_recovered ?? 0)],
                ["Repairs completed", metrics.repairs_completed ?? 0],
                ["Corrupted replicas", metrics.corrupted_replicas ?? 0],
                ["Missing replicas", metrics.missing_replicas ?? 0],
              ].map(([label, value]) => (
                <div key={String(label)}><small>{label}</small><strong>{value}</strong></div>
              ))}
            </div>
          </section>

          <section className="panel" aria-labelledby="events-heading">
            <div className="panelhead"><h2 id="events-heading">Event timeline</h2></div>
            <div className="timeline" role="log" aria-live="polite">
              {events.slice(0, 18).map((event) => (
                <div key={event.id}>
                  <b>{event.event_type}</b>
                  <small>{new Date(event.timestamp).toLocaleTimeString()}</small>
                  <p>{event.message}</p>
                </div>
              ))}
            </div>
          </section>
        </div>

        <footer className="footerstatus" role="contentinfo">
          <span><span className="liveDot" aria-hidden="true" /> Vault connected</span>
          <span>{lastUpdated ? `Last refreshed ${lastUpdated.toLocaleTimeString()}` : "Waiting for first refresh…"}</span>
        </footer>
      </main>
    </div>
  );
}

createRoot(document.getElementById("root")!).render(<App />);
