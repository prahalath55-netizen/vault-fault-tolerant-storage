import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

// Backend URL the dev-server proxies /api to. Overridable so the demo
// still works if the backend isn't on the default port.
const BACKEND = process.env.VAULT_BACKEND_URL || "http://127.0.0.1:8000";

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    proxy: {
      // Proxying means the browser always calls same-origin "/api/...",
      // so CORS and localhost-vs-127.0.0.1-vs-wrong-port mismatches
      // between the Vite dev server and FastAPI can never break requests.
      "/api": {
        target: BACKEND,
        changeOrigin: true,
      },
    },
  },
});
