import pytest
@pytest.fixture
def system(tmp_path,monkeypatch):
    import vault.config as cfg
    monkeypatch.setattr(cfg,"DATA_DIR",tmp_path/"data");monkeypatch.setattr(cfg,"NODE_IDS",["node_1","node_2","node_3"])
    from vault.metadata import Metadata
    from vault.storage import Storage
    from vault.health import Health
    from vault.repair import Repair
    from vault.coordinator import Coordinator
    m=Metadata(tmp_path/"vault.db");s=Storage(m);h=Health(m);r=Repair(m,s);c=Coordinator(m,s,h,r)
    return m,s,h,r,c
