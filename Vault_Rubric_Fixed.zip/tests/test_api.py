def test_api_health():
    from fastapi.testclient import TestClient
    from vault.api import app
    with TestClient(app) as c:assert c.get("/api/health").status_code==200

def test_demo_run_end_to_end(monkeypatch, tmp_path):
    # Regression test for the "Run Fault-Tolerance Demo" button: previously
    # only the coordinator-level flow (test_demo.py) was covered, never the
    # actual HTTP endpoint the frontend calls.
    import vault.config as cfg
    monkeypatch.setattr(cfg, "DATA_DIR", tmp_path / "data")
    monkeypatch.setattr(cfg, "DB_PATH", tmp_path / "data" / "vault.db")
    monkeypatch.setattr(cfg, "NODE_IDS", ["node_1", "node_2", "node_3"])

    from fastapi.testclient import TestClient
    from vault.api import app

    with TestClient(app) as c:
        res = c.post("/api/demo/run")
        assert res.status_code == 200
        body = res.json()

        assert body["object"]["filename"] == "demo_payload.txt"
        replica_states = {r["node_id"]: r["state"] for r in body["replicas"]}
        assert replica_states == {"node_1": "HEALTHY", "node_2": "HEALTHY", "node_3": "HEALTHY"}

        # The full lifecycle the dashboard is supposed to demonstrate must
        # all be present in the event timeline.
        event_types = {e["event_type"] for e in body["events"]}
        expected = {
            "OBJECT_UPLOADED", "REPLICATION_STARTED", "REPLICA_CREATED",
            "OBJECT_RETRIEVED", "NODE_FAILED", "CORRUPTION_DETECTED",
            "REPAIR_STARTED", "REPLICA_REPAIRED", "INTEGRITY_VERIFIED",
            "NODE_RECOVERING", "NODE_RECOVERED",
        }
        missing = expected - event_types
        assert not missing, f"demo run is missing expected event types: {missing}"

        assert body["metrics"]["healthy_nodes"] == 3
        assert body["metrics"]["corrupted_replicas"] == 0  # repaired by the end

        # Running it again (as a second button click would) must also work.
        res2 = c.post("/api/demo/run")
        assert res2.status_code == 200

def test_cors_allows_alternate_vite_port(monkeypatch, tmp_path):
    # If port 5173 is taken, Vite falls back to another port (e.g. 5174).
    # The dashboard must still be reachable from that origin.
    import vault.config as cfg
    monkeypatch.setattr(cfg, "DATA_DIR", tmp_path / "data")
    monkeypatch.setattr(cfg, "DB_PATH", tmp_path / "data" / "vault.db")
    monkeypatch.setattr(cfg, "NODE_IDS", ["node_1", "node_2", "node_3"])

    from fastapi.testclient import TestClient
    from vault.api import app

    with TestClient(app) as c:
        res = c.get("/api/health", headers={"Origin": "http://localhost:5174"})
        assert res.headers.get("access-control-allow-origin") == "http://localhost:5174"

def test_delete_object(monkeypatch, tmp_path):
    # Regression test: Metadata.delete_object previously passed a bare
    # string instead of a 1-tuple to sqlite3, which raised on every call.
    import vault.config as cfg
    monkeypatch.setattr(cfg, "DATA_DIR", tmp_path / "data")
    monkeypatch.setattr(cfg, "DB_PATH", tmp_path / "data" / "vault.db")
    monkeypatch.setattr(cfg, "NODE_IDS", ["node_1", "node_2", "node_3"])

    from fastapi.testclient import TestClient
    from vault.api import app

    with TestClient(app) as c:
        oid = c.post("/api/demo/run").json()["object"]["object_id"]
        res = c.delete(f"/api/objects/{oid}")
        assert res.status_code == 200
        assert res.json() == {"deleted": True, "object_id": oid}
        assert c.get(f"/api/objects/{oid}").status_code == 404
