from pathlib import Path


def test_delete_removes_object_metadata_and_files(system):
    m, s, _h, _r, coordinator = system
    source = Path(s.root.parent / "delete-me.txt")
    source.write_text("delete test", encoding="utf-8")

    obj = coordinator.upload(source, source.name)
    oid = obj["object_id"]
    assert m.object(oid) is not None
    assert len(m.replicas(oid)) == 3

    s.delete_object_everywhere(oid)
    m.delete_object(oid)

    assert m.object(oid) is None
    for node in s.node_ids:
        assert not s.object_path(node, oid).exists()
