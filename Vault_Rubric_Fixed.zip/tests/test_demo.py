def test_full_fault_tolerance_flow(system, tmp_path):
    m,s,h,r,c = system
    payload = tmp_path / "demo.txt"
    payload.write_bytes(b"Vault demo payload\n" * 100)
    obj = c.upload(payload, "demo.txt")
    oid = obj["object_id"]
    assert c.retrieve(oid)[0].read_bytes() == payload.read_bytes()
    h.fail("node_2")
    assert c.retrieve(oid)[1] in {"node_1", "node_3"}
    s.corrupt("node_3", oid)
    audit = c.audit(oid)
    assert any(x["state"] == "CORRUPTED" for x in audit)
    assert r.repair(oid, "node_3")
    h.recover("node_2")
    assert r.repair(oid, "node_2")
    assert all(x["state"] == "HEALTHY" for x in c.audit(oid))
