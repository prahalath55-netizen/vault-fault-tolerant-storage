def test_corruption_detected_and_repaired(system,tmp_path):
    m,s,h,r,c=system;f=tmp_path/"x";f.write_bytes(b"repair me");o=c.upload(f,"x");oid=o["object_id"];s.corrupt("node_3",oid);a=c.audit(oid);assert any(x["state"]=="CORRUPTED" for x in a);assert r.repair(oid,"node_3");assert any(x["state"]=="HEALTHY" for x in c.audit(oid))
