def test_failover(system,tmp_path):
    m,s,h,r,c=system;f=tmp_path/"x";f.write_bytes(b"hello");o=c.upload(f,"x");h.fail("node_1");p,n=c.retrieve(o["object_id"]);assert n in {"node_2","node_3"};assert p.read_bytes()==b"hello"
