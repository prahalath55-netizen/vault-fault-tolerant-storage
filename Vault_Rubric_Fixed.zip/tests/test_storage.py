def test_real_replication_and_path_security(system,tmp_path):
    import pytest
    m,s,h,r,c=system;f=tmp_path/"x";f.write_bytes(b"abc");o=c.upload(f,"x")
    assert all(s.object_path(x["node_id"],o["object_id"]).exists() for x in m.replicas(o["object_id"]))
    with pytest.raises(Exception):s.object_path("node_1","../../secret")
