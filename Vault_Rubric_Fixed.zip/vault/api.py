"""FastAPI application for Vault object storage."""

import logging
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse

from .config import DB_PATH, MAX_UPLOAD_BYTES, NODE_IDS
from .coordinator import Coordinator
from .health import Health
from .metadata import Metadata
from .metrics import metrics
from .models import CorruptRequest, RepairRequest
from .repair import Repair
from .storage import Storage

logger = logging.getLogger("vault.api")
metadata = Metadata(DB_PATH)
storage = Storage(metadata)
health = Health(metadata)
repair = Repair(metadata, storage)
coordinator = Coordinator(metadata, storage, health, repair)


@asynccontextmanager
async def lifespan(_app: FastAPI):
    yield


app = FastAPI(title="Vault", version="1.0.0", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_origin_regex=r"^https?://(localhost|127\.0\.0\.1)(:\d+)?$",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/health")
def get_health():
    return {"status": "ok", "metrics": metrics(metadata, storage)}


@app.get("/api/nodes")
def get_nodes():
    return metadata.nodes()


@app.post("/api/nodes/{node_id}/fail")
def fail_node(node_id: str):
    try:
        health.fail(node_id)
        return metadata.node(node_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="Node not found") from None


@app.post("/api/nodes/{node_id}/recover")
def recover_node(node_id: str):
    try:
        health.recover(node_id)
        repair_results = []
        for obj in metadata.objects():
            repair_results.extend(repair.repair(obj["object_id"], node_id))
        metadata.set_node_state(node_id, "HEALTHY")
        metadata.event("NODE_RECOVERED", f"{node_id} recovered", node_id=node_id)
        return {**metadata.node(node_id), "repairs": repair_results}
    except KeyError:
        raise HTTPException(status_code=404, detail="Node not found") from None
    except Exception as exc:
        logger.exception("Node recovery failed for %s", node_id)
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@app.get("/api/objects")
def get_objects():
    return [
        {**obj, "replicas": metadata.replicas(obj["object_id"])}
        for obj in metadata.objects()
    ]


@app.post("/api/objects")
async def upload_object(file: UploadFile = File(...)):
    if not file.filename:
        raise HTTPException(status_code=422, detail="Filename required")

    safe_name = Path(file.filename).name
    temporary_path = storage.root.parent / "_uploads" / safe_name
    temporary_path.parent.mkdir(parents=True, exist_ok=True)
    total = 0

    try:
        with temporary_path.open("wb") as output:
            while chunk := await file.read(1024 * 1024):
                total += len(chunk)
                if total > MAX_UPLOAD_BYTES:
                    raise HTTPException(status_code=413, detail="Upload too large")
                output.write(chunk)
        return coordinator.upload(temporary_path, safe_name)
    finally:
        temporary_path.unlink(missing_ok=True)


@app.get("/api/objects/{object_id}")
def get_object(object_id: str):
    obj = metadata.object(object_id)
    if not obj:
        raise HTTPException(status_code=404, detail="Object not found")
    return {**obj, "replicas": metadata.replicas(object_id)}


@app.delete("/api/objects/{object_id}")
def delete_object(object_id: str):
    if not metadata.object(object_id):
        raise HTTPException(status_code=404, detail="Object not found")
    storage.delete_object_everywhere(object_id)
    metadata.delete_object(object_id)
    metadata.event("OBJECT_DELETED", f"Object {object_id} deleted", object_id)
    return {"deleted": True, "object_id": object_id}


@app.get("/api/objects/{object_id}/download")
def download_object(object_id: str):
    try:
        path, node_id = coordinator.retrieve(object_id)
        obj = metadata.object(object_id)
        return FileResponse(
            path,
            filename=obj["filename"],
            headers={"X-Vault-Source-Node": node_id},
        )
    except KeyError:
        raise HTTPException(status_code=404, detail="Object not found") from None
    except Exception as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@app.post("/api/objects/{object_id}/verify")
def verify_object(object_id: str):
    try:
        return {"object_id": object_id, "replicas": coordinator.audit(object_id)}
    except KeyError:
        raise HTTPException(status_code=404, detail="Object not found") from None


@app.post("/api/objects/{object_id}/repair")
def repair_object(object_id: str, request: RepairRequest | None = None):
    try:
        target = request.node_id if request else None
        return {"object_id": object_id, "repairs": repair.repair(object_id, target)}
    except KeyError:
        raise HTTPException(status_code=404, detail="Object not found") from None
    except Exception as exc:
        logger.exception("Repair failed for %s", object_id)
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@app.post("/api/replicas/{object_id}/corrupt")
def corrupt_replica(object_id: str, request: CorruptRequest):
    if not metadata.object(object_id):
        raise HTTPException(status_code=404, detail="Object not found")
    try:
        storage.corrupt(request.node_id, object_id)
        metadata.set_replica_state(object_id, request.node_id, "DEGRADED")
        metadata.event(
            "REPLICA_CORRUPTED",
            "Replica deliberately corrupted",
            object_id,
            request.node_id,
        )
        return {"status": "corrupted"}
    except Exception as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@app.get("/api/metrics")
def get_metrics():
    return metrics(metadata, storage)


@app.get("/api/events")
def get_events():
    return metadata.events()


@app.get("/api/repairs")
def get_repairs():
    return metadata.repairs()


def reset_cluster():
    storage.reset_files()
    metadata.reset()
    for node_id in NODE_IDS:
        metadata.upsert_node(node_id, "HEALTHY", str(storage.node_path(node_id)))


@app.post("/api/demo/reset")
def reset_demo():
    reset_cluster()
    return {"status": "reset"}


@app.post("/api/demo/run")
def run_demo():
    reset_cluster()
    demo_path = storage.root.parent / "demo_payload.txt"
    demo_path.write_bytes(b"Vault fault tolerance demo payload\n" * 2048)

    try:
        obj = coordinator.upload(demo_path, "demo_payload.txt")
        object_id = obj["object_id"]
        coordinator.retrieve(object_id)

        health.fail("node_2")
        coordinator.retrieve(object_id)

        storage.corrupt("node_3", object_id)
        coordinator.audit(object_id)
        repair.repair(object_id, "node_3")

        health.recover("node_2")
        repair.repair(object_id, "node_2")
        metadata.set_node_state("node_2", "HEALTHY")
        metadata.event("NODE_RECOVERED", "node_2 recovered", node_id="node_2")

        return {
            "object": metadata.object(object_id),
            "replicas": metadata.replicas(object_id),
            "metrics": metrics(metadata, storage),
            "events": metadata.events(),
        }
    finally:
        demo_path.unlink(missing_ok=True)
