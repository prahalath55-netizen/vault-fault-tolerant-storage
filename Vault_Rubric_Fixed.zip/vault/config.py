from pathlib import Path
import os
BASE_DIR=Path(__file__).resolve().parent.parent
DATA_DIR=Path(os.getenv("VAULT_DATA_DIR",BASE_DIR/"vault_data")).resolve()
DB_PATH=Path(os.getenv("VAULT_DATABASE",DATA_DIR/"vault.db")).resolve()
NODE_COUNT=int(os.getenv("VAULT_NODE_COUNT","3"))
REPLICATION_FACTOR=int(os.getenv("VAULT_REPLICATION_FACTOR","3"))
MAX_UPLOAD_BYTES=int(os.getenv("VAULT_MAX_UPLOAD_BYTES",str(100*1024*1024)))
NODE_IDS=[f"node_{i}" for i in range(1,NODE_COUNT+1)]
