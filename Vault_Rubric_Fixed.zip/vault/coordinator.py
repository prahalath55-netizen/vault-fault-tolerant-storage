"""Replication, retrieval, and integrity coordination."""

from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from .config import MAX_UPLOAD_BYTES, REPLICATION_FACTOR
from .integrity import sha256_file


class Coordinator:
    """Coordinate object lifecycle across metadata and storage layers."""

    def __init__(self, metadata, storage, health, repair):
        self.metadata = metadata
        self.storage = storage
        self.health = health
        self.repair = repair

    def upload(self, source: Path, filename: str, replication_factor: int = REPLICATION_FACTOR):
        size = source.stat().st_size
        if size > MAX_UPLOAD_BYTES:
            raise ValueError("Upload too large")

        object_id = uuid4().hex
        digest, size = sha256_file(source)
        healthy_nodes = [
            node["node_id"]
            for node in self.metadata.nodes()
            if node["state"] == "HEALTHY"
        ]
        if len(healthy_nodes) < replication_factor:
            raise RuntimeError("Insufficient healthy nodes")

        self.metadata.add_object(
            (
                object_id,
                filename,
                size,
                digest,
                datetime.now(timezone.utc).isoformat(),
                replication_factor,
            )
        )
        self.metadata.event("OBJECT_UPLOADED", f"{filename} uploaded", object_id)
        self.metadata.event(
            "REPLICATION_STARTED",
            f"Replicating to {replication_factor} nodes",
            object_id,
        )

        for node_id in healthy_nodes[:replication_factor]:
            replica_path = self.storage.write(node_id, object_id, source)
            replica_digest, replica_size = sha256_file(replica_path)
            if replica_digest != digest or replica_size != size:
                raise RuntimeError("Replica verification failed")
            self.metadata.upsert_replica(
                object_id, node_id, "HEALTHY", replica_digest, replica_size
            )
            self.metadata.event(
                "REPLICA_CREATED",
                f"Replica created on {node_id}",
                object_id,
                node_id,
            )
        return self.metadata.object(object_id)

    def candidates(self, object_id: str):
        obj = self.metadata.object(object_id)
        if not obj:
            raise KeyError(object_id)

        candidates = []
        for replica in self.metadata.replicas(object_id):
            node = self.metadata.node(replica["node_id"])
            if not node or node["state"] != "HEALTHY":
                continue
            try:
                path = self.storage.read_path(replica["node_id"], object_id)
                digest, size = sha256_file(path)
                if digest == obj["sha256"] and size == obj["size"]:
                    candidates.append((replica["node_id"], path))
                else:
                    self.metadata.set_replica_state(
                        object_id, replica["node_id"], "CORRUPTED"
                    )
                    self.metadata.event(
                        "CORRUPTION_DETECTED",
                        "Checksum mismatch",
                        object_id,
                        replica["node_id"],
                    )
            except FileNotFoundError:
                self.metadata.set_replica_state(
                    object_id, replica["node_id"], "MISSING"
                )
            except Exception:
                self.metadata.set_replica_state(
                    object_id, replica["node_id"], "UNAVAILABLE"
                )
        return candidates

    def retrieve(self, object_id: str):
        candidates = self.candidates(object_id)
        if not candidates:
            raise FileNotFoundError("No verified healthy replica")
        node_id, path = candidates[0]
        self.metadata.event(
            "OBJECT_RETRIEVED", f"Read from {node_id}", object_id, node_id
        )
        return path, node_id

    def audit(self, object_id: str):
        obj = self.metadata.object(object_id)
        if not obj:
            raise KeyError(object_id)

        results = []
        for replica in self.metadata.replicas(object_id):
            result = dict(replica)
            result["expected_sha256"] = obj["sha256"]
            previous_state = replica["state"]
            try:
                path = self.storage.object_path(replica["node_id"], object_id)
                if not path.exists():
                    result["state"] = "MISSING"
                elif self.metadata.node(replica["node_id"])["state"] == "FAILED":
                    result["state"] = "UNAVAILABLE"
                else:
                    digest, size = sha256_file(path)
                    result["actual_sha256"] = digest
                    result["state"] = (
                        "HEALTHY"
                        if digest == obj["sha256"] and size == obj["size"]
                        else "CORRUPTED"
                    )
                    self.metadata.set_replica_state(
                        object_id, replica["node_id"], result["state"]
                    )
            except Exception:
                result["state"] = "UNAVAILABLE"

            if result["state"] == "CORRUPTED" and previous_state != "CORRUPTED":
                self.metadata.event(
                    "CORRUPTION_DETECTED",
                    "Checksum mismatch",
                    object_id,
                    replica["node_id"],
                )
            elif result["state"] == "MISSING" and previous_state != "MISSING":
                self.metadata.event(
                    "REPLICA_MISSING",
                    "Replica file missing",
                    object_id,
                    replica["node_id"],
                )
            results.append(result)
        return results
