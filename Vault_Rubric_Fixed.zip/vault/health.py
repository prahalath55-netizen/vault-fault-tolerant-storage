"""Node failure and recovery state transitions."""

from .models import NodeState


class Health:
    """Manage simulated storage-node health state."""

    def __init__(self, metadata):
        self.metadata = metadata

    def fail(self, node_id: str) -> None:
        if not self.metadata.node(node_id):
            raise KeyError(node_id)
        self.metadata.set_node_state(node_id, NodeState.FAILED)
        self.metadata.event("NODE_FAILED", f"{node_id} failed", node_id=node_id)

    def recover(self, node_id: str) -> None:
        if not self.metadata.node(node_id):
            raise KeyError(node_id)
        self.metadata.set_node_state(node_id, NodeState.RECOVERING)
        self.metadata.event("NODE_RECOVERING", f"{node_id} recovering", node_id=node_id)
