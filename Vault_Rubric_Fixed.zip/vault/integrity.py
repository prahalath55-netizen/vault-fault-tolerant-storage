"""Content-integrity helpers."""

from hashlib import sha256
from pathlib import Path
from typing import Tuple


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> Tuple[str, int]:
    """Return the SHA-256 digest and byte size of a file."""
    digest = sha256()
    size = 0
    with path.open("rb") as handle:
        while chunk := handle.read(chunk_size):
            digest.update(chunk)
            size += len(chunk)
    return digest.hexdigest(), size
