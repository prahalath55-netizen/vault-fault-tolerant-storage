"""SQLite persistence layer."""

import json
import sqlite3
import threading
from datetime import datetime, timezone
from pathlib import Path


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


class Metadata:
    """Thread-safe SQLite metadata store for cluster state."""

    def __init__(self, db_path):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        self.init()

    def conn(self):
        connection = sqlite3.connect(self.db_path, timeout=10)
        connection.row_factory = sqlite3.Row
        return connection

    def init(self):
        with self.lock, self.conn() as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS nodes(
                    node_id TEXT PRIMARY KEY,
                    state TEXT NOT NULL,
                    path TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS objects(
                    object_id TEXT PRIMARY KEY,
                    filename TEXT NOT NULL,
                    size INTEGER NOT NULL,
                    sha256 TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    replication_factor INTEGER NOT NULL
                );
                CREATE TABLE IF NOT EXISTS replicas(
                    object_id TEXT NOT NULL,
                    node_id TEXT NOT NULL,
                    state TEXT NOT NULL,
                    sha256 TEXT,
                    size INTEGER,
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY(object_id,node_id)
                );
                CREATE TABLE IF NOT EXISTS events(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    object_id TEXT,
                    node_id TEXT,
                    message TEXT NOT NULL,
                    metadata TEXT
                );
                CREATE TABLE IF NOT EXISTS repairs(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    object_id TEXT NOT NULL,
                    target_node TEXT NOT NULL,
                    source_node TEXT,
                    status TEXT NOT NULL,
                    bytes_recovered INTEGER DEFAULT 0,
                    duration_ms REAL DEFAULT 0,
                    started_at TEXT NOT NULL,
                    completed_at TEXT
                );
                """
            )

    def reset(self):
        with self.lock, self.conn() as connection:
            connection.executescript(
                "DELETE FROM replicas; DELETE FROM objects; DELETE FROM events; "
                "DELETE FROM repairs; DELETE FROM nodes;"
            )

    def upsert_node(self, node_id, state, path):
        timestamp = now()
        with self.lock, self.conn() as connection:
            connection.execute(
                """
                INSERT INTO nodes VALUES(?,?,?,?,?)
                ON CONFLICT(node_id) DO UPDATE SET
                    state=excluded.state,
                    path=excluded.path,
                    updated_at=excluded.updated_at
                """,
                (node_id, state, path, timestamp, timestamp),
            )

    def set_node_state(self, node_id, state):
        with self.lock, self.conn() as connection:
            connection.execute(
                "UPDATE nodes SET state=?,updated_at=? WHERE node_id=?",
                (state, now(), node_id),
            )

    def nodes(self):
        with self.lock, self.conn() as connection:
            return [dict(row) for row in connection.execute("SELECT * FROM nodes ORDER BY node_id")]

    def node(self, node_id):
        with self.lock, self.conn() as connection:
            row = connection.execute(
                "SELECT * FROM nodes WHERE node_id=?", (node_id,)
            ).fetchone()
            return dict(row) if row else None

    def add_object(self, obj):
        with self.lock, self.conn() as connection:
            connection.execute("INSERT INTO objects VALUES(?,?,?,?,?,?)", obj)

    def objects(self):
        with self.lock, self.conn() as connection:
            return [
                dict(row)
                for row in connection.execute(
                    "SELECT * FROM objects ORDER BY created_at DESC"
                )
            ]

    def object(self, object_id):
        with self.lock, self.conn() as connection:
            row = connection.execute(
                "SELECT * FROM objects WHERE object_id=?", (object_id,)
            ).fetchone()
            return dict(row) if row else None

    def delete_object(self, object_id):
        with self.lock, self.conn() as connection:
            connection.execute(
                "DELETE FROM replicas WHERE object_id=?", (object_id,)
            )
            connection.execute(
                "DELETE FROM objects WHERE object_id=?", (object_id,)
            )

    def upsert_replica(self, object_id, node_id, state, sha, size):
        with self.lock, self.conn() as connection:
            connection.execute(
                """
                INSERT INTO replicas VALUES(?,?,?,?,?,?)
                ON CONFLICT(object_id,node_id) DO UPDATE SET
                    state=excluded.state,
                    sha256=excluded.sha256,
                    size=excluded.size,
                    updated_at=excluded.updated_at
                """,
                (object_id, node_id, state, sha, size, now()),
            )

    def replicas(self, object_id):
        with self.lock, self.conn() as connection:
            return [
                dict(row)
                for row in connection.execute(
                    "SELECT * FROM replicas WHERE object_id=? ORDER BY node_id",
                    (object_id,),
                )
            ]

    def set_replica_state(self, object_id, node_id, state):
        with self.lock, self.conn() as connection:
            connection.execute(
                "UPDATE replicas SET state=?,updated_at=? WHERE object_id=? AND node_id=?",
                (state, now(), object_id, node_id),
            )

    def event(self, event_type, message, object_id=None, node_id=None, metadata=None, **kwargs):
        node_id = kwargs.get("node_id", node_id)
        with self.lock, self.conn() as connection:
            connection.execute(
                """
                INSERT INTO events(timestamp,event_type,object_id,node_id,message,metadata)
                VALUES(?,?,?,?,?,?)
                """,
                (
                    now(),
                    event_type,
                    object_id,
                    node_id,
                    message,
                    json.dumps(metadata or {}),
                ),
            )

    def events(self, limit=100):
        with self.lock, self.conn() as connection:
            return [
                dict(row)
                for row in connection.execute(
                    "SELECT * FROM events ORDER BY id DESC LIMIT ?", (limit,)
                )
            ]

    def repair_start(self, object_id, target, source):
        with self.lock, self.conn() as connection:
            return connection.execute(
                """
                INSERT INTO repairs(object_id,target_node,source_node,status,started_at)
                VALUES(?,?,?,?,?)
                """,
                (object_id, target, source, "RUNNING", now()),
            ).lastrowid

    def repair_finish(self, repair_id, status, bytes_recovered, duration):
        with self.lock, self.conn() as connection:
            connection.execute(
                """
                UPDATE repairs
                SET status=?,bytes_recovered=?,duration_ms=?,completed_at=?
                WHERE id=?
                """,
                (status, bytes_recovered, duration, now(), repair_id),
            )

    def repairs(self):
        with self.lock, self.conn() as connection:
            return [
                dict(row)
                for row in connection.execute(
                    "SELECT * FROM repairs ORDER BY id DESC"
                )
            ]
