"""Cluster and recovery metrics."""


def metrics(metadata, storage):
    nodes = metadata.nodes()
    objects = metadata.objects()
    physical = healthy = missing = corrupted = 0

    for obj in objects:
        for replica in metadata.replicas(obj["object_id"]):
            try:
                path = storage.object_path(replica["node_id"], obj["object_id"])
                if not path.exists():
                    missing += 1
                    continue
                physical += path.stat().st_size
                if replica["state"] == "HEALTHY":
                    healthy += 1
                else:
                    corrupted += 1
            except Exception:
                missing += 1

    logical = sum(obj["size"] for obj in objects)
    repairs = metadata.repairs()
    completed = [repair for repair in repairs if repair["status"] == "COMPLETED"]

    return {
        "object_count": len(objects),
        "logical_bytes": logical,
        "physical_bytes": physical,
        "replication_factor": max(
            (obj["replication_factor"] for obj in objects), default=3
        ),
        "total_nodes": len(nodes),
        "healthy_nodes": sum(node["state"] == "HEALTHY" for node in nodes),
        "failed_nodes": sum(node["state"] == "FAILED" for node in nodes),
        "degraded_nodes": sum(node["state"] == "DEGRADED" for node in nodes),
        "recovering_nodes": sum(node["state"] == "RECOVERING" for node in nodes),
        "replica_count": sum(len(metadata.replicas(obj["object_id"])) for obj in objects),
        "healthy_replica_count": healthy,
        "missing_replicas": missing,
        "corrupted_replicas": corrupted,
        "bytes_recovered": sum(repair["bytes_recovered"] or 0 for repair in completed),
        "repairs_completed": len(completed),
        "repair_duration_ms": sum(repair["duration_ms"] or 0 for repair in completed),
        "storage_overhead": physical / logical if logical else 0,
    }
