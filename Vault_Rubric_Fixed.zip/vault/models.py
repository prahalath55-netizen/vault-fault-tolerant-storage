"""Pydantic request models and node states."""

from enum import Enum

from pydantic import BaseModel, Field


class NodeState(str, Enum):
    HEALTHY = "HEALTHY"
    FAILED = "FAILED"
    DEGRADED = "DEGRADED"
    RECOVERING = "RECOVERING"


class RepairRequest(BaseModel):
    node_id: str | None = Field(default=None, max_length=128)


class CorruptRequest(BaseModel):
    node_id: str = Field(min_length=1, max_length=128)
