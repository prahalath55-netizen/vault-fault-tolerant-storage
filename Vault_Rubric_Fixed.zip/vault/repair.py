"""Replica repair service."""

import time

from .integrity import sha256_file
from .models import NodeState


class Repair:
    """Restore unhealthy replicas from a verified healthy source."""

    def __init__(self, metadata, storage):
        self.metadata = metadata
        self.storage = storage

    def repair(self, object_id: str, target: str | None = None):
        obj = self.metadata.object(object_id)
        if not obj:
            raise KeyError(object_id)

        results = []
        for replica in self.metadata.replicas(object_id):
            target_node = replica["node_id"]
            if target and target_node != target:
                continue

            if self._is_valid_replica(obj, target_node):
                continue

            source_node = self._find_verified_source(obj, target_node)
            if not source_node:
                continue

            repair_id = self.metadata.repair_start(object_id, target_node, source_node)
            started = time.perf_counter()
            self.metadata.set_node_state(target_node, NodeState.RECOVERING)
            self.metadata.event(
                "REPAIR_STARTED",
                f"Repairing {target_node} from {source_node}",
                object_id,
                target_node,
            )
            try:
                repaired_path = self.storage.copy(
                    source_node, target_node, object_id
                )
                digest, size = sha256_file(repaired_path)
                if digest != obj["sha256"] or size != obj["size"]:
                    raise RuntimeError("Post-repair verification failed")

                self.metadata.upsert_replica(
                    object_id, target_node, "HEALTHY", digest, size
                )
                self.metadata.set_node_state(target_node, NodeState.HEALTHY)
                duration_ms = (time.perf_counter() - started) * 1000
                self.metadata.repair_finish(
                    repair_id, "COMPLETED", size, duration_ms
                )
                self.metadata.event(
                    "REPLICA_REPAIRED",
                    f"Replica repaired from {source_node}",
                    object_id,
                    target_node,
                )
                self.metadata.event(
                    "INTEGRITY_VERIFIED",
                    "SHA-256 verified",
                    object_id,
                    target_node,
                )
                results.append(
                    {
                        "target": target_node,
                        "source": source_node,
                        "bytes": size,
                        "duration_ms": duration_ms,
                    }
                )
            except Exception:
                self.metadata.repair_finish(
                    repair_id,
                    "FAILED",
                    0,
                    (time.perf_counter() - started) * 1000,
                )
                raise
        return results

    def _is_valid_replica(self, obj, node_id: str) -> bool:
        node = self.metadata.node(node_id)
        if not node or node["state"] != "HEALTHY":
            return False
        try:
            path = self.storage.object_path(node_id, obj["object_id"])
            digest, size = sha256_file(path)
            return digest == obj["sha256"] and size == obj["size"]
        except Exception:
            return False

    def _find_verified_source(self, obj, excluded_node: str) -> str | None:
        for replica in self.metadata.replicas(obj["object_id"]):
            source = replica["node_id"]
            if source == excluded_node:
                continue
            if self._is_valid_replica(obj, source):
                return source
        return None
