"""Safe local-filesystem storage-node abstraction."""

import re
import shutil
from pathlib import Path

from . import config

SAFE_ID = re.compile(r"^[A-Za-z0-9_-]{1,128}$")


class StorageError(Exception):
    """Base class for storage-layer failures."""


class NodeUnavailable(StorageError):
    """Raised when a node cannot serve the requested operation."""


class Storage:
    """Store object replicas inside isolated directories per node."""

    def __init__(self, metadata):
        self.metadata = metadata
        self.root = config.DATA_DIR / "nodes"
        self.root.mkdir(parents=True, exist_ok=True)
        for node_id in config.NODE_IDS:
            node_path = self.root / node_id
            node_path.mkdir(parents=True, exist_ok=True)
            metadata.upsert_node(node_id, "HEALTHY", str(node_path))

    @property
    def node_ids(self) -> list[str]:
        return list(config.NODE_IDS)

    @staticmethod
    def validate(identifier: str) -> None:
        if not SAFE_ID.fullmatch(identifier):
            raise StorageError("Invalid identifier")

    def node_path(self, node_id: str) -> Path:
        self.validate(node_id)
        root = self.root.resolve()
        path = (root / node_id).resolve()
        if root not in path.parents:
            raise StorageError("Unsafe path")
        return path

    def object_path(self, node_id: str, object_id: str) -> Path:
        self.validate(node_id)
        self.validate(object_id)
        base = self.node_path(node_id)
        path = (base / object_id).resolve()
        if base not in path.parents:
            raise StorageError("Unsafe path")
        return path

    def available(self, node_id: str) -> bool:
        node = self.metadata.node(node_id)
        return bool(node and node["state"] == "HEALTHY")

    def destination_available(self, node_id: str) -> bool:
        node = self.metadata.node(node_id)
        return bool(node and node["state"] in {"HEALTHY", "RECOVERING"})

    def write(self, node_id: str, object_id: str, source: Path) -> Path:
        if not self.destination_available(node_id):
            raise NodeUnavailable(node_id)
        destination = self.object_path(node_id, object_id)
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, destination)
        return destination

    def copy(self, source_node: str, destination_node: str, object_id: str) -> Path:
        if not self.available(source_node):
            raise NodeUnavailable(source_node)
        if not self.destination_available(destination_node):
            raise NodeUnavailable(destination_node)
        source = self.object_path(source_node, object_id)
        if not source.exists():
            raise FileNotFoundError(source)
        destination = self.object_path(destination_node, object_id)
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, destination)
        return destination

    def read_path(self, node_id: str, object_id: str) -> Path:
        if not self.available(node_id):
            raise NodeUnavailable(node_id)
        path = self.object_path(node_id, object_id)
        if not path.exists():
            raise FileNotFoundError(path)
        return path

    def corrupt(self, node_id: str, object_id: str) -> None:
        path = self.read_path(node_id, object_id)
        with path.open("r+b") as handle:
            first_byte = handle.read(1)
            if first_byte:
                handle.seek(0)
                handle.write(bytes([first_byte[0] ^ 0xFF]))
            else:
                handle.write(b"X")

    def delete_object_everywhere(self, object_id: str) -> None:
        """Delete an object's physical replicas from every configured node."""
        self.validate(object_id)
        for node_id in self.node_ids:
            path = self.object_path(node_id, object_id)
            if path.exists():
                path.unlink()

    def reset_files(self) -> None:
        """Clear simulated object files while retaining node directories."""
        for node_id in self.node_ids:
            node_path = self.root / node_id
            node_path.mkdir(parents=True, exist_ok=True)
            for child in node_path.iterdir():
                if child.is_file():
                    child.unlink()
